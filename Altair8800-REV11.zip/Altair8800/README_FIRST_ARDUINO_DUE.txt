Altair 8800 Simulator - Enhanced Due Build REV11
Date: 2026-05-23

Open this sketch in Arduino IDE:

  Altair8800_REV10_SaveLoad_Settings_Fix/Altair8800.ino

Default boot settings:

  CPU target : 20 MHz
  RAM        : 64 KB
  Console    : USB Programming Port / Micro USB
  Baud       : 115200 8N1
  Throttle   : off / full speed

Persistent-save fix:

  REV11 keeps the REV10 nonvolatile/internal-flash save fixes and adds switchable Intel 8080/Z80 CPU selection. REV10 restored real nonvolatile internal-flash saving on Arduino Due when no
  SD STORAGE.DAT backend is active. To make your current settings survive a
  real power loss, enter the config menu, press S, save as config #0, and answer
  y if asked to overwrite. Config #0 is the normal power-on default.

Fast setup:

  STOP + AUX1   config menu
  !             max performance profile
  S             save
  0             default config number
  y             overwrite if asked
  x             exit


REV11 IMPORTANT CPU + PERSISTENCE NOTE
-------------------------------
REV10 intentionally ignores older saved config records from REV9 and below.
This prevents the old 250 kHz / cycle-governed config from coming back after
a power loss. First boot after REV10 should use the compiled max defaults.
Then save config #0 again if you want your current menu selections to be the
power-on config.


REV11 Z80 NOTE
--------------
REV11 compiles with USE_Z80=2.  That enables the configuration-menu CPU selector:

  Pro(c)essor : Intel 8080 / Zilog Z80

Press STOP + AUX1 for the configuration menu, press c to toggle CPU type, then
S to save config #0 if you want that CPU to be the power-on default.  The reset
default profile prefers Z80, but an already-saved REV10 config may still boot
in Intel 8080 mode until you toggle and save.

For original Altair 8080-only software, Intel 8080 mode remains available as a
safe fallback.  For CP/M and Z80-aware programs, select Zilog Z80.

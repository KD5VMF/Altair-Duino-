param(
    [Parameter(Mandatory=$true)]
    [string]$Port
)

Write-Host "================================================================"
Write-Host " Altair8800 Due Z80 Final REV14 TURBO - Easy BIN Upload"
Write-Host "================================================================"
Write-Host ""

$Bossac = Join-Path $PSScriptRoot "bossac.exe"
$Bin = Join-Path $PSScriptRoot "altair8800_REV14.bin"

if (!(Test-Path $Bossac)) {
    Write-Host "ERROR: bossac.exe was not found in this folder." -ForegroundColor Red
    Write-Host "Put bossac.exe next to this script and try again."
    exit 1
}

if (!(Test-Path $Bin)) {
    Write-Host "ERROR: altair8800_REV14.bin was not found in this folder." -ForegroundColor Red
    exit 1
}

Write-Host "Port: $Port"
Write-Host "BIN : $Bin"
Write-Host ""
Write-Host "If upload fails, press ERASE on the Due, press RESET, then run this again."
Write-Host ""

& $Bossac -i -d --port=$Port -U false -e -w -v -b $Bin -R
if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "Upload FAILED. Check COM port, cable, and that this is the Arduino Due programming port." -ForegroundColor Red
    exit $LASTEXITCODE
}

Write-Host ""
Write-Host "Upload complete. The Arduino Due should reset into REV14 TURBO." -ForegroundColor Green

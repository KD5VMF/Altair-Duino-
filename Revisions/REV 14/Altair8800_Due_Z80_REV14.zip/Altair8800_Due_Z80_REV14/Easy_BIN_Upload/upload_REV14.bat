@echo off
setlocal

echo ================================================================
echo  Altair8800 Due Z80 Final REV14 TURBO - Easy BIN Upload
echo ================================================================
echo.

if "%~1"=="" (
  echo Usage:
  echo   upload_REV14.bat COM7
  echo.
  echo Example:
  echo   upload_REV14.bat COM7
  echo.
  echo Replace COM7 with your Arduino Due programming port.
  echo.
  pause
  exit /b 1
)

set PORT=%~1
set BIN=altair8800_REV14.bin

if not exist bossac.exe (
  echo ERROR: bossac.exe was not found in this folder.
  echo Put bossac.exe next to this batch file and try again.
  pause
  exit /b 1
)

if not exist "%BIN%" (
  echo ERROR: %BIN% was not found in this folder.
  pause
  exit /b 1
)

echo Port: %PORT%
echo BIN : %BIN%
echo.
echo If upload fails, press ERASE on the Due, press RESET, then run this again.
echo.

bossac.exe -i -d --port=%PORT% -U false -e -w -v -b "%BIN%" -R

if errorlevel 1 (
  echo.
  echo Upload FAILED.
  echo Check COM port, cable, and that this is the Arduino Due programming port.
  pause
  exit /b 1
)

echo.
echo Upload complete. The Arduino Due should reset into REV14 TURBO.
pause

Altair8800 Due Z80 Final REV14 TURBO - Easy BIN Upload
======================================================

Files in this folder:

  altair8800_REV14.bin      Prebuilt Arduino Due firmware BIN
  bossac.exe                You add this file here
  upload_REV14.bat          Simple Windows batch uploader
  upload_REV14.ps1          PowerShell uploader

Fast use:

  1. Put bossac.exe in this folder.
  2. Plug the Arduino Due into the Programming Port.
  3. Find the COM port in Windows Device Manager.
  4. Run one of these:

       upload_REV14.bat COM7

     or:

       powershell -ExecutionPolicy Bypass -File .\upload_REV14.ps1 -Port COM7

  5. Replace COM7 with your actual COM port.

If upload fails:

  - Make sure you are using the Arduino Due Programming Port, not the Native USB port.
  - Press ERASE on the Due.
  - Press RESET.
  - Run the upload command again.

REV14 TURBO note:

  Use ! Max Perf from the Altair menu for the fastest raw emulation speed.
  In raw full-speed mode, REV14 reduces front-panel GPIO overhead while still
  keeping live LED activity visible during RUN.

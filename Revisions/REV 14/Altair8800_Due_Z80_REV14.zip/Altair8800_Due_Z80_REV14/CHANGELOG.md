# Changelog

## REV14 TURBO - 2026-05-25

- Added fast front-panel RUN mode for raw full-speed execution.
- Reduced per-instruction GPIO/front-panel overhead.
- Kept live LED activity during RUN using periodic sampling.
- Kept normal front-panel behavior for STOP, WAIT, STEP, EXAMINE, DEPOSIT, RESET, and governed clock modes.
- Added easy Windows BIN upload folder and scripts.
- Updated documentation for GitHub release use.

## REV13

- Stable 8080/Z80 build baseline.
- Preserved CPU opcode audit work.
- Preserved save/load and clock configuration fixes.

## Earlier revisions

See the source folder notes for REV4 through REV12 history.

# Quick Flash on Windows

1. Open the package folder.
2. Open `Easy_BIN_Upload`.
3. Put `bossac.exe` in that same folder.
4. Connect the Arduino Due with the **Programming Port**.
5. Find the COM port in Device Manager.
6. Open PowerShell or Command Prompt in `Easy_BIN_Upload`.
7. Run:

```bat
upload_REV14.bat COM7
```

Replace `COM7` with your actual port.

PowerShell option:

```powershell
powershell -ExecutionPolicy Bypass -File .\upload_REV14.ps1 -Port COM7
```

If it fails, press **ERASE**, press **RESET**, then run the upload command again.

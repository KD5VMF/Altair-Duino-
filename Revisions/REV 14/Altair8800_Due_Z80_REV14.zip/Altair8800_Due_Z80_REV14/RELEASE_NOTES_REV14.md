# REV14 TURBO Release Notes

## Release name

**Altair8800 Due Z80 Final REV14 TURBO**

## Summary

REV14 is a speed-focused release for the Arduino Due build. It keeps the previous 8080/Z80 work and adds a faster front-panel RUN mode that reduces GPIO overhead while keeping the LEDs visibly active during execution.

## User-visible improvements

- Faster CPU-heavy CP/M programs and benchmark loops.
- Better practical Z80 performance on the Arduino Due.
- Front LEDs still show live activity during RUN.
- STOP/WAIT/STEP/EXAMINE/DEPOSIT remain normal.
- `!` Max Perf mode is now more useful for real speed testing.

## What changed internally

- Added `USE_FAST_RUN_FRONT_PANEL` in `config.h`.
- Added `FAST_RUN_PANEL_SAMPLE_MASK` for periodic live LED sampling.
- Added `altair_fast_run_front_panel` runtime state.
- Optimized opcode fetch/front-panel update path in raw full-speed RUN.
- Optimized MEM_READ/MEM_WRITE fast paths.
- Optimized stack and 16-bit memory helper paths used by the 8080/Z80 cores.
- Kept accurate/governed timing behavior outside raw full-speed mode.

## Recommended benchmark mode

```text
CPU            : Z80
Throttle       : off / full speed
Profiling      : off
Serial panel   : off
Serial debug   : off
Max perf       : !
```

## Important reality check

The Arduino Due is still a single-core 84 MHz ARM Cortex-M3 board. REV14 makes the emulator more efficient, but it cannot make the Due equal to a real 20 MHz hardware Z80. The biggest gains should show up in pure CPU/math loops, while disk and serial-heavy workloads will still be limited by emulated I/O overhead.

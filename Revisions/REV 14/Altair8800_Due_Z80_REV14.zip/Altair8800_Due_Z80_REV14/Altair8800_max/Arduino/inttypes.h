#ifndef INTTYPES_H
#define INTTYPES_H

typedef signed   char  int8_t;
typedef signed   short int16_t;
typedef signed   int   int32_t;
typedef unsigned char  uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int   uint32_t;
typedef uint8_t        byte;
typedef uint32_t       word;

#endif

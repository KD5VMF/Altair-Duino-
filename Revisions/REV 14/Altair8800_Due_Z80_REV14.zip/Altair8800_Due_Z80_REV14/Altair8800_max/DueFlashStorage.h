// -----------------------------------------------------------------------------
// Local DueFlashStorage compatibility layer for Arduino Due / SAM3X8E.
//
// REV8 nonvolatile-save fix, 2026-05-23:
// - Removed dependency on <flash_efc.h> because some Arduino Due/SAM core
//   installs do not ship that header in a public include path.
// - Implements the small DueFlashStorage API used by this project directly
//   against the SAM3X Enhanced Embedded Flash Controller registers.
// - This is used only when the normal SD-backed STORAGE.DAT storage file is not
//   available. If STORAGE.DAT is available, the main program still uses it first.
//
// Safety notes:
// - Flash has finite write endurance. Save configuration when needed, not in a
//   tight loop.
// - The original project reserves the last 16 KB of the Due's flash. Keep the
//   compiled sketch under the limit printed by the Arduino IDE so saved settings
//   do not overlap program code.
// - Addressing matches the original DueFlashStorage convention:
//   readAddress(0) maps to IFLASH1_ADDR. host_due.cpp adds FLASH_STORAGE_OFFSET.
// -----------------------------------------------------------------------------
#ifndef ALTAIR_LOCAL_DUE_FLASH_STORAGE_COMPAT_H
#define ALTAIR_LOCAL_DUE_FLASH_STORAGE_COMPAT_H

#include <Arduino.h>
#include <string.h>

#ifndef IFLASH1_ADDR
#define IFLASH1_ADDR (0x000C0000UL)
#endif

#ifndef IFLASH1_SIZE
#define IFLASH1_SIZE (0x00040000UL)
#endif

#ifndef IFLASH_PAGE_SIZE
#define IFLASH_PAGE_SIZE (256UL)
#endif

#ifndef IFLASH_NB_OF_PAGES
#define IFLASH_NB_OF_PAGES (IFLASH1_SIZE / IFLASH_PAGE_SIZE)
#endif

// Minimal EEFC register view. This avoids depending on flash_efc.h while still
// using the same SAM3X hardware block that the Arduino Due core uses.
typedef struct
{
  volatile uint32_t FMR;
  volatile uint32_t FCR;
  volatile uint32_t FSR;
  volatile uint32_t FRR;
} AltairEfcRegisters;

#define ALTAIR_EFC1 ((AltairEfcRegisters *)0x400E0C00UL)

#define ALTAIR_EEFC_FSR_FRDY   (1UL << 0)
#define ALTAIR_EEFC_FSR_FCMDE  (1UL << 1)
#define ALTAIR_EEFC_FSR_FLOCKE (1UL << 2)

#define ALTAIR_EEFC_FCMD_WP    (0x01UL) // Write page
#define ALTAIR_EEFC_FCMD_EWP   (0x03UL) // Erase page and write page
#define ALTAIR_EEFC_FCMD_CLB   (0x09UL) // Clear lock bit
#define ALTAIR_EEFC_FKEY       (0x5AUL << 24)
#define ALTAIR_EEFC_FARG(x)    (((uint32_t)(x) & 0xFFFFUL) << 8)

class DueFlashStorage
{
public:
  DueFlashStorage() {}

  byte *readAddress(uint32_t address)
  {
    return (byte *)(IFLASH1_ADDR + address);
  }

  void write(uint32_t address, byte value)
  {
    write(address, &value, 1);
  }

  void write(uint32_t address, const byte *data, uint32_t length)
  {
    write(address, (byte *)data, length);
  }

  void write(uint32_t address, byte *data, uint32_t length)
  {
    if( data==NULL || length==0 ) return;

#if defined(__SAM3X8E__)
    uint32_t pos = 0;
    while( pos < length )
      {
        uint32_t absolute = IFLASH1_ADDR + address + pos;
        if( absolute < IFLASH1_ADDR || absolute >= (IFLASH1_ADDR + IFLASH1_SIZE) ) return;

        uint32_t page = (absolute - IFLASH1_ADDR) / IFLASH_PAGE_SIZE;
        uint32_t pageOffset = (absolute - IFLASH1_ADDR) % IFLASH_PAGE_SIZE;
        uint32_t pageBase = IFLASH1_ADDR + page * IFLASH_PAGE_SIZE;
        uint32_t chunk = IFLASH_PAGE_SIZE - pageOffset;
        if( chunk > (length - pos) ) chunk = length - pos;

        byte pageBuf[IFLASH_PAGE_SIZE];
        memcpy(pageBuf, (const void *)pageBase, IFLASH_PAGE_SIZE);
        memcpy(pageBuf + pageOffset, data + pos, chunk);

        writePage(page, pageBuf);
        pos += chunk;
      }
#else
    (void) address;
    (void) data;
    (void) length;
#endif
  }

private:
#if defined(__SAM3X8E__)
  static void waitReady()
  {
    while( (ALTAIR_EFC1->FSR & ALTAIR_EEFC_FSR_FRDY)==0 ) { }
  }

  static void performCommand(uint32_t command, uint32_t argument)
  {
    waitReady();
    ALTAIR_EFC1->FCR = ALTAIR_EEFC_FKEY | ALTAIR_EEFC_FARG(argument) | command;
    waitReady();
  }

  static void writePage(uint32_t page, const byte *pageBuf)
  {
    if( page >= IFLASH_NB_OF_PAGES ) return;

    uint32_t pageBase = IFLASH1_ADDR + page * IFLASH_PAGE_SIZE;
    const uint32_t *src = (const uint32_t *)pageBuf;
    volatile uint32_t *dst = (volatile uint32_t *)pageBase;

    // Writing to the flash address loads the EEFC page latch. EWP then erases
    // and writes that page. Interrupts are disabled so USB/SysTick does not
    // execute from flash in the middle of the flash command.
    noInterrupts();

    // Make sure the storage lock region is not locked. This is harmless if it
    // is already unlocked.
    performCommand(ALTAIR_EEFC_FCMD_CLB, page);

    for( uint32_t i=0; i<(IFLASH_PAGE_SIZE/4); i++ )
      dst[i] = src[i];

    performCommand(ALTAIR_EEFC_FCMD_EWP, page);

    interrupts();
  }
#endif
};

#endif

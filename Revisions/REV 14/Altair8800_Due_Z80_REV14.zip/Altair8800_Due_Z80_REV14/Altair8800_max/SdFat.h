// -----------------------------------------------------------------------------
// Local SdFat compatibility shim for Arduino Due builds.
//
// Why this exists:
//   The original Altair8800 Arduino Due host code expected Bill Greiman's SdFat
//   library. Some Arduino IDE installs do not have SdFat installed, which causes:
//       fatal error: SdFat.h: No such file or directory
//   Also, Arduino's stock SD library on Due has no SD.rename(), so this shim
//   emulates rename using copy-then-delete.
//
// This header lets the Due build compile using the standard Arduino SD library.
// It implements the small SdFat surface used by this project: begin(), open(),
// exists(), remove(), rename(), and a minimal card()->errorCode() info object.
//
// For maximum SD performance you can still install the real SdFat library and
// remove/rename this shim, but this package is intended to compile out-of-box.
// -----------------------------------------------------------------------------
#ifndef ALTAIR_LOCAL_SDFAT_COMPAT_H
#define ALTAIR_LOCAL_SDFAT_COMPAT_H

#include <Arduino.h>
#include <SPI.h>

// Avoid a name collision with this project's own static object named "SD".
// The stock SD library declares a global object named SD. We do not use that
// global; we instantiate our own SDClass inside the SdFat-compatible wrapper.
#define SD ALTAIR_DO_NOT_USE_GLOBAL_ARDUINO_SD_OBJECT
#include <SD.h>
#undef SD

#ifndef SD_FAT_VERSION
#define SD_FAT_VERSION 29999
#endif

#ifndef SD_CARD_ERROR_NONE
#define SD_CARD_ERROR_NONE 0
#endif

#ifndef SPI_DIV3_SPEED
#define SPI_DIV3_SPEED 0
#endif

#ifndef SD_SCK_MHZ
#define SD_SCK_MHZ(mhz) (0)
#endif

#ifndef SD_SCK_HZ
#define SD_SCK_HZ(hz) (0)
#endif

#define ALTAIR_USE_STANDARD_SD_COMPAT 1

class Altair_SdFatCardCompat
{
public:
  uint8_t errorCode() const { return SD_CARD_ERROR_NONE; }
  uint32_t cardSize() const { return 0; }
  uint32_t sectorCount() const { return 0; }
};

class SdFat
{
public:
  SdFat() {}

  bool begin(uint8_t csPin)
  {
    return m_sd.begin(csPin);
  }

  bool begin(uint8_t csPin, uint32_t /*speed*/)
  {
    return m_sd.begin(csPin);
  }

  File open(const char *filename, uint8_t mode = FILE_READ)
  {
    return m_sd.open(filename, mode);
  }

  bool exists(const char *filename)
  {
    return m_sd.exists(filename);
  }

  bool remove(const char *filename)
  {
    return m_sd.remove(filename);
  }

  bool rename(const char *from, const char *to)
  {
    // Arduino's stock SDClass on the Due does not provide rename().
    // Emulate it safely by copy-then-delete so old project code can keep
    // calling SD.rename(...).
    if( from==NULL || to==NULL ) return false;
    if( !m_sd.exists(from) ) return false;

    if( m_sd.exists(to) )
      {
        if( !m_sd.remove(to) ) return false;
      }

    File src = m_sd.open(from, FILE_READ);
    if( !src ) return false;

    File dst = m_sd.open(to, FILE_WRITE);
    if( !dst )
      {
        src.close();
        return false;
      }

    uint8_t buffer[128];
    bool ok = true;

    while( src.available()>0 )
      {
        int n = src.read(buffer, sizeof(buffer));
        if( n<=0 )
          {
            ok = false;
            break;
          }

        if( dst.write(buffer, (size_t) n)!=(size_t) n )
          {
            ok = false;
            break;
          }
      }

    dst.flush();
    dst.close();
    src.close();

    if( ok )
      {
        ok = m_sd.remove(from);
        if( !ok ) m_sd.remove(to);
      }
    else
      {
        m_sd.remove(to);
      }

    return ok;
  }

  Altair_SdFatCardCompat *card()
  {
    return &m_card;
  }

private:
  SDClass m_sd;
  Altair_SdFatCardCompat m_card;
};

// Lets the Teensy host file at least compile if this local shim is seen there.
typedef SdFat SdFatSdio;

#endif

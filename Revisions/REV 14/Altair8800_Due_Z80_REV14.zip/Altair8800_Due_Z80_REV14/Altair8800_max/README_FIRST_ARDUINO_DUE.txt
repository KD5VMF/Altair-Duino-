Altair8800 Due Z80 Final REV13
==============================

Open this sketch in the Arduino IDE:

  Altair8800_Due_Z80_Final_REV13/Altair8800.ino

Use this board target:

  Tools -> Board -> Arduino Due (Programming Port)

Use this terminal setup:

  115200 baud, 8 data bits, no parity, 1 stop bit

FINAL REV13 IMPORTANT NOTES
---------------------------

1. The live startup banner should say:

     Final REV13 - Stable 8080/Z80 + opcode audit - Created 2026-05-24

2. This build keeps the switchable CPU setup:

     Pro(c)essor : Intel 8080 / Zilog Z80

   Use the 'c' command in the configuration menu to toggle CPU mode.
   Save as config #0 to make the selected CPU the power-on default.

3. This build keeps the REV10 save/load and clock-governor fixes.
   Save reports success only after the config header can be read back.

4. Clock target keys k, K, and G automatically enable governed target speed.
   Use ! when you intentionally want max-performance/full-speed mode.

5. The default compiled profile is:

     CPU       : Zilog Z80
     Target    : 20 MHz
     Throttle  : off / full speed
     RAM       : 64 KB
     Console   : USB Programming Port / Micro USB
     Baud      : 115200 8N1

SAVE POWER-ON SETTINGS
----------------------

Enter the configuration menu with STOP + AUX1, then:

  !      apply max-performance profile
  c      toggle CPU if needed
  S      save configuration
  0      save as config #0
  y      overwrite if asked
  x      exit

If persistence is unreliable without an SD card, use a working SD card so the
firmware can create/use STORAGE.DAT. Arduino Due internal flash emulation can be
less reliable than SD-backed storage.
